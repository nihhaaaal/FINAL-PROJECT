# Django-Resume-Builder
A simple website made in Django-Python to help users build resumes using Simple forms
